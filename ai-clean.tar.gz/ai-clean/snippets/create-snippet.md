Title: Create Snippet Prompt
Description: Generates a snippet template based on provided example code. Template contains instructions and example code. Provide more examples for coverage if needed. Don't include obvious steps you already know like imports.
Body:

### Instructions

Title: ${1:Create ${2:Component}}
Description: Generates a template for ${3:a ${2}}
Body:

${5:$TM_SELECTED_TEXT}

### Example

Title: ${1}
Description: ${3}
Body:

${5}
